####################################################################################
#########  Tree-like pairwise interaction network (PIN)
#########  Compute SHAP on a pre-fitted PIN architecture
#########  Author: Ronald Richman, Salvatore Scognamiglio, Mario Wuthrich
#########  Version August 2025
####################################################################################

## This code computes paired-sampling PermutationSHAP on a pre-fitted PIN

## load packages
library(arrow)
library(tidyverse)
library(patchwork)
library(tensorflow)
library(keras)
library(waterfalls)

## disable GPU
Sys.setenv("CUDA_VISIBLE_DEVICES" = -1)

####################################################################################
#########  Poisson deviance loss
####################################################################################

## define deviance loss (we scale with 10^2 for better visisbility)
Poisson.Deviance <- function(pred, obs, weight){
  10^2 * 2*(sum(pred)-sum(obs)+sum(log((obs/pred)^(obs))))/sum(weight)
  }

####################################################################################
#########  load and pre-process data
####################################################################################



## load data
load(file="freMTPL2freqClean.rda")
dat <- freMTPL2freqClean

## pre-process data for FNN - standardization
PreProcess.Continuous <- function(var1, dat2){
   names(dat2)[names(dat2) == var1]  <- "V1"
   dat2$X <- as.numeric(dat2$V1)
   dat2$X <- (dat2$X-mean(dat2$X))/sd(dat2$X)
   names(dat2)[names(dat2) == "V1"]  <- var1
   names(dat2)[names(dat2) == "X"]  <- paste(var1,"X", sep="")
   dat2
   }

Features.PreProcess <- function(dat2){
   dat2 <- PreProcess.Continuous("Area", dat2)
   dat2 <- PreProcess.Continuous("VehPower", dat2)
   dat2$VehAge <- pmin(dat2$VehAge,20)
   dat2 <- PreProcess.Continuous("VehAge", dat2)
   dat2$DrivAge <- pmin(dat2$DrivAge,90)
   dat2 <- PreProcess.Continuous("DrivAge", dat2)
   dat2$BonusMalus <- pmin(dat2$BonusMalus,150)
   dat2 <- PreProcess.Continuous("BonusMalus", dat2)
   dat2$VehBrandX <- as.integer(dat2$VehBrand)-1
   dat2$VehGasX <- as.integer(dat2$VehGas)-1
   dat2$Density <- round(log(dat2$Density),2)
   dat2 <- PreProcess.Continuous("Density", dat2)
   dat2$RegionX <- as.integer(dat2$Region)-1
   dat2
    }

dat <- Features.PreProcess(dat)




## select learning and test samples (identical to W�thrich-Merz, Springer 2023)
learn <- dat[which(dat$LearnTest=='L'),]
test  <- dat[which(dat$LearnTest=='T'),]
str(learn)


####################################################################################
#########  Benchmark: Poisson GLM
####################################################################################

round(mu.hom <- sum(learn$ClaimNb)/sum(learn$Exposure), 4)

####################################################################################
#########  Define PIN architecture
####################################################################################

## centered hard sigmoid function
CenteredHardSigmoidLayer <- Layer(
  classname = "CenteredHardSigmoidLayer",
  initialize = function() {
    super()$`__init__`()
  },
  call = function(inputs, ...) {
    x <- inputs
    x <- tf$maximum(tf$minimum((1+x)/2, 1), 0)
    x
  },
  compute_output_shape = function(input_shape) {
    input_shape
  }
)


## pairwise interaction layer

PairwiseInteractionLayer <- Layer(
  classname = "PairwiseInteractionLayer",
  initialize = function(emb1=1L, units1 = 16L, units2 = 8L, token_dim=5L, ...) {
    super()$`__init__`()
    self$units1 <- units1
    self$units2 <- units2
    self$token_dim <- as.integer(token_dim)
    self$embed_dim <- as.integer(emb1)
    self$interaction_network <- NULL
    self$num_features <- 0
    self$interaction_embeddings <- NULL
  },
  build = function(input_shape) {
    num_features <- input_shape[[2]]
    self$num_features <- num_features
    num_interactions <- as.integer((num_features * (num_features + 1)) / 2)
    hard_sigmoid <- CenteredHardSigmoidLayer()
    #
    ### Create shared interaction network
    inputs <- layer_input(shape = c(2*self$embed_dim + self$token_dim), name = "interaction_inputs")
    #
    dense1 <- layer_dense(inputs, units = self$units1, name = "interaction_dense1")
    activation1 <- layer_activation(dense1, activation = 'relu', name = "interaction_activation1")
    #
    dense2 <- layer_dense(activation1, units = self$units2,  name = "interaction_dense2")
    activation2 <- layer_activation(dense2, activation = 'relu', name = "interaction_activation2")
    #
    outputs <- layer_dense(activation2, units = 1L, activation = 'linear')  %>%
               hard_sigmoid()
    self$interaction_network <- keras_model(inputs = inputs, outputs = outputs, name = "interaction_network")
    #
    ### Create a unique interaction token
    self$interaction_token <- self$add_weight(
      name = 'interaction_token',
      shape = list(num_interactions, self$token_dim),
      initializer = 'uniform',
      trainable = TRUE
    )
    print("finished building")
  },
  call = function(inputs, ...) {
    num_features <- self$num_features
    interactions <- list()
    k = 0
    interaction_index <- 1
    for (i in 1:(num_features)) {
      for (j in i:num_features) {
        # select the pairs
        input_pair <- tf$concat(list(inputs[,i,], inputs[,j,]), axis = -1L)
        # Get the corresponding interaction token
        embed_lookup = tf$broadcast_to(self$interaction_token[interaction_index,,drop=TRUE], tf$stack(list(tf$shape(input_pair)[1], self$token_dim)))
        interaction_index <- interaction_index + 1
        # Concatenate the interaction token with the input pair
        input_with_embedding <- tf$concat(list(input_pair, embed_lookup), axis = -1L)
        # Pass these through shared interaction network
        interaction_output <- self$interaction_network(input_with_embedding)
        interactions[[k + 1]] <- interaction_output
        k = k + 1
      }
    }
    # Concatenate all interaction outputs
    interactions_concat <- tf$concat(interactions, axis = -1L)
    interactions_concat
  },
  compute_output_shape = function(input_shape) {
    num_features <- input_shape[[length(input_shape)]]
    num_interactions <- (num_features * (num_features + 1)) / 2
    c(input_shape[1], num_interactions)
  }
)


## pairwise interaction network (PIN)

PIN <- function(seed, q0, kk){
    tf$keras$backend$clear_session()
    set.seed(seed)
    set_random_seed(seed)
    embedding_list = list()
    #
    Design   <- layer_input(shape = c(q0[1]), dtype = 'float32')
    Volume   <- layer_input(shape = c(1), dtype = 'float32')
    #
    BrandEmb = Design[,q0[1]-1] %>%
      layer_embedding(input_dim = kk[1], output_dim = q0[3], input_length = 1) %>%
      layer_reshape(target_shape = c(1, q0[3]))
    #
    RegionEmb = Design[,q0[1]] %>%
      layer_embedding(input_dim = kk[2], output_dim = q0[3], input_length = 1) %>%
      layer_reshape(target_shape = c(1, q0[3]))
    #
    for (count in 1:(q0[1]-2)){
      embedding_list[[count]] = Design[,count:count] %>%
      layer_dense(units = q0[2]) %>%
      layer_dense(units = q0[3], activation = "tanh")  %>%
      layer_reshape(target_shape = c(1, q0[3]))
     }
    Embeds = embedding_list %>% layer_concatenate(axis = 1)
    Embeds = list(Embeds, BrandEmb, RegionEmb) %>% layer_concatenate(axis = 1)
    Pairs = PairwiseInteractionLayer(emb1=q0[3], units1=q0[4], units2=q0[5], token_dim=q0[6])
    Network = Embeds %>% Pairs %>% layer_dense(units = 1, activation = "exponential")
    Response = list(Network, Volume) %>% layer_multiply()
    keras_model(inputs = c(Design, Volume), outputs = c(Response))
    }


####################################################################################
#########  Prepare data for PIN
####################################################################################

# define the feature vector
features <- c("Area", "VehPower", "VehAge", "DrivAge", "BonusMalus",
              "VehGas", "Density", "VehBrand", "Region")

(q0 <- length(features))
Xlearn  <- as.matrix(learn[, paste0(features,"X")])  # design matrix learning sample
Xtest   <- as.matrix(test[, paste0(features,"X")])   # design matrix test sample
Vlearn  <- as.matrix(learn$Exposure)     # time exposure
Vtest   <- as.matrix(test$Exposure)      # time exposure
Ylearn  <- as.matrix(learn$ClaimNb)
Ytest   <- as.matrix(test$ClaimNb)



####################################################################################
#########  Select the PIN hyper-parameters
####################################################################################

d1  <- c(10)       # embedding dimension
d2  <- c(20)       # FNN layer for continuous embedding
q1  <- c(30, 20)   # shared interaction network
d0  <- c(10)       # token dimension

qq <- c(q0, d2, d1, q1, d0)

# levels of categorical variables
kk <- c(length(unique(learn$VehBrandX)), length(unique(learn$RegionX)))

####################################################################################
#########  Load one PIN architecture and compute the loss statistics
####################################################################################

seed  <- 100
model <- PIN(seed=seed, q0=qq, kk=kk)
model

path1 <- paste0("./Networks/PIN_Diag",seed,".weights.h5")
load_model_weights_hdf5(model,path1)
learn$PIN =  as.vector(model %>% predict(list(Xlearn, Vlearn), batch_size = 2048))
test$PIN  =  as.vector(model %>% predict(list(Xtest, Vtest), batch_size = 2048))

round(c(Poisson.Deviance(learn$PIN, learn$ClaimNb, rep(1, nrow(learn))),
        Poisson.Deviance(test$PIN, test$ClaimNb, rep(1, nrow(test)))), 3)


####################################################################################
#########  PIN paired-sampling permutation SHAP
####################################################################################

set.seed(100)
bg0 <- 2000      # size background dataset
I0  <- 100       # number of instances for SHAP decomposition
background <- sample(nrow(learn), bg0)   # for estimating interventional SHAP means
ind        <- sample(nrow(learn), I0)    # to be SHAP analyzed


Shapley <- array(NA, dim=c(I0, length(features)))
Norm    <- array(NA, dim=c(I0,2))

## Compute paired-sampling PermutationSHAP of the selected instances
## One permutation pair is sufficient for value functions of maximal order 2.

{t1 <- proc.time()
for (i0 in c(1:I0)){
  XSHAP1  <- learn[c(ind[i0],background[-1]), paste0(features,"X")]
  XSHAP2  <- XSHAP1
  XSHAP0  <- XSHAP1
  for (j0 in 1:length(features)){
     XSHAP0[,j0] <- XSHAP0[1,j0]
     XSHAP1 <- rbind(XSHAP1, XSHAP0)
    }
  XSHAP0  <- XSHAP2
  for (j0 in rev(1:length(features))){
     XSHAP0[,j0] <- XSHAP0[1,j0]
     XSHAP2 <- rbind(XSHAP2, XSHAP0)
   }
  XSHAP1  <- as.matrix(XSHAP1)
  XSHAP2  <- as.matrix(XSHAP2)
  VSHAP  <- as.matrix(rep(1,nrow(XSHAP1)))
  pi1    <- log(as.vector(model %>% predict(list(XSHAP1, VSHAP), batch_size = 2048, verbose=0)))
  pi1    <- array(pi1, dim=c(bg0, length(features)+1))
  pi1    <- colMeans(pi1)
  Norm[i0,]  <- pi1[c(1,length(features)+1)]
  pi2    <- log(as.vector(model %>% predict(list(XSHAP2, VSHAP), batch_size = 2048, verbose=0)))
  pi2    <- array(pi2, dim=c(bg0, length(features)+1))
  pi2    <- colMeans(pi2)
  Norm[i0,]  <- pi1[c(1,length(features)+1)]
  for (j0 in 1:length(features)){
       Shapley[i0, j0] <- (pi1[j0+1] - pi1[j0] + pi2[length(features)-j0+2] - pi2[length(features)-j0+1])/2
              }
  }
(proc.time()-t1)[3]}


####################################################################################
#########  Illustrate SHAP results
####################################################################################


### select an instance for a waterfall SHAP plot
i0 <- 4
learn[ind[i0],c(1:14,24)]

df <- data.frame(features)
df$SHAP <- round(Shapley[i0,], 2)

# 2 is the global mean E[f(X)], 1 is the individual prediction f(x)
Norm[i0,]


waterfall(df, rect_text_size = 1.5) +
  labs(title = paste0("waterfall plot of a single instance"),
       x = "feature components",
       y = "Shapley values") +
  theme_minimal() +
    theme(axis.text.x = element_text(angle = 90, size=14),
          axis.text.y = element_text(size=14),
          axis.title = element_text(size = 16),
          plot.title = element_text(size = 18, face = "bold"))



### SHAP variable importance (based on the selected 100 instances)

SHAPImportance <- data.frame(colMeans(abs(Shapley)))
names(SHAPImportance) <- "VI"
SHAPImportance$X <- features
SHAPImportance <- SHAPImportance[(order(SHAPImportance$VI)),]

## default c(5.1,4.1,4.1,2.1)
par(mar=c(5.1,6.1,4.1,2.1))
barplot(t(as.matrix(SHAPImportance[,1])), las=1, col="orange", names.arg=SHAPImportance[,2], main=list("SHAP variable importance", cex=1.5), horiz=TRUE)



### from local to global SHAP (based on the selected 100 instances)

## select DrivAge Variable
j0 <- 4
# strongest interaction
learn$BM <- floor(learn$BonusMalus/10)
learn$BM0 <- as.integer(as.factor(learn$BM))
BM <- length(unique(learn[ind,"BM0"]))
col0 <- rev(rainbow(n=BM, start=0, end=1/3))
BM1 <- sort(unique(learn[ind,]$BM))*10


plot(x=learn[ind, features[j0]], y=Shapley[,j0], cex=1.5, cex.lab=1.25, pch=19, col=col0[learn[ind,]$BM0],
     ylab="Shapley values", xlab="driver's age", main=list(paste0("Shapley values ",features[j0]), cex=1.5))
abline(h=0, lty=2)
legend(x="bottomright", pch=19, cex=1.5, lwd=-1, lty=-1, col=col0, legend=paste0("BM ",BM1))
