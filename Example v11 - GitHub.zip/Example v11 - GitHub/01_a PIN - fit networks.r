####################################################################################
#########  Tree-like pairwise interaction network (PIN)
#########  Fitting PINs and computing loss statistics
#########  Author: Ronald Richman, Salvatore Scognamiglio, Mario Wuthrich
#########  Version August 2025
####################################################################################

## load packages
library(arrow)
library(tidyverse)
library(patchwork)
library(tensorflow)
library(keras)

## disable GPU
Sys.setenv("CUDA_VISIBLE_DEVICES" = -1)

####################################################################################
#########  Poisson deviance loss
####################################################################################

## define deviance loss (we scale with 10^2 for better visisbility)
Poisson.Deviance <- function(pred, obs, weight){
  10^2 * 2*(sum(pred)-sum(obs)+sum(log((obs/pred)^(obs))))/sum(weight)
  }

####################################################################################
#########  load and pre-process data
####################################################################################

## load data
load(file="freMTPL2freqClean.rda")
dat <- freMTPL2freqClean

## pre-process data for GLM
dat$AreaGLM       <- as.integer(dat$Area)
dat$VehPowerGLM   <- as.factor(pmin(dat$VehPower, 9))
dat$VehAgeGLM     <- as.factor(cut(dat$VehAge, c(0,5,12,101),
                       labels = c("0-5", "6-12", "12+"),
                       include.lowest = TRUE))
dat$DrivAgeGLM    <- as.factor(cut(dat$DrivAge, c(18,20,25,30,40,50,70,101),
                       labels = c("18-20", "21-25", "26-30", "31-40", "41-50", "51-70", "71+"),
                       include.lowest = TRUE))
dat$DrivAgeGLM    <- relevel(dat[,"DrivAgeGLM"], ref="31-40")
dat$BonusMalusGLM <- pmin(dat$BonusMalus, 150)
dat$DensityGLM    <- log(dat$Density)

## pre-process data for FNN - standardization
PreProcess.Continuous <- function(var1, dat2){
   names(dat2)[names(dat2) == var1]  <- "V1"
   dat2$X <- as.numeric(dat2$V1)
   dat2$X <- (dat2$X-mean(dat2$X))/sd(dat2$X)
   names(dat2)[names(dat2) == "V1"]  <- var1
   names(dat2)[names(dat2) == "X"]  <- paste(var1,"X", sep="")
   dat2
   }

Features.PreProcess <- function(dat2){
   dat2 <- PreProcess.Continuous("Area", dat2)
   dat2 <- PreProcess.Continuous("VehPower", dat2)
   dat2$VehAge <- pmin(dat2$VehAge,20)
   dat2 <- PreProcess.Continuous("VehAge", dat2)
   dat2$DrivAge <- pmin(dat2$DrivAge,90)
   dat2 <- PreProcess.Continuous("DrivAge", dat2)
   dat2$BonusMalus <- pmin(dat2$BonusMalus,150)
   dat2 <- PreProcess.Continuous("BonusMalus", dat2)
   dat2$VehBrandX <- as.integer(dat2$VehBrand)-1
   dat2$VehGasX <- as.integer(dat2$VehGas)-1
   dat2$Density <- round(log(dat2$Density),2)
   dat2 <- PreProcess.Continuous("Density", dat2)
   dat2$RegionX <- as.integer(dat2$Region)-1
   dat2
    }

dat <- Features.PreProcess(dat)

## select learning and test samples (identical to W�thrich-Merz, Springer 2023)
learn <- dat[which(dat$LearnTest=='L'),]
test  <- dat[which(dat$LearnTest=='T'),]
str(learn)

####################################################################################
#########  Benchmark: Poisson GLM
####################################################################################

round(mu.hom <- sum(learn$ClaimNb)/sum(learn$Exposure), 4)

d.glm <- glm(ClaimNb ~ VehPowerGLM + VehAgeGLM + DrivAgeGLM + BonusMalusGLM
                       + VehBrand + VehGas + DensityGLM + Region + AreaGLM,
                           data=learn, offset=log(Exposure), family=poisson())

learn$GLM <- fitted(d.glm)
test$GLM  <- predict(d.glm, newdata=test, type="response")

rbind(round(c(Poisson.Deviance(learn$GLM, learn$ClaimNb, learn$Exposure), Poisson.Deviance(test$GLM, test$ClaimNb, test$Exposure)), 3),
      round(c(Poisson.Deviance(mu.hom*learn$Exposure, learn$ClaimNb, learn$Exposure), Poisson.Deviance(mu.hom*test$Exposure, test$ClaimNb, test$Exposure)), 3))

####################################################################################
#########  Define PIN architecture
####################################################################################

## centered hard sigmoid function
CenteredHardSigmoidLayer <- Layer(
  classname = "CenteredHardSigmoidLayer",
  initialize = function() {
    super()$`__init__`()
  },
  call = function(inputs, ...) {
    x <- inputs
    x <- tf$maximum(tf$minimum((1+x)/2, 1), 0)
    x
  },
  compute_output_shape = function(input_shape) {
    input_shape
  }
)


## pairwise interaction layer

PairwiseInteractionLayer <- Layer(
  classname = "PairwiseInteractionLayer",
  initialize = function(emb1=1L, units1 = 16L, units2 = 8L, token_dim=5L, ...) {
    super()$`__init__`()
    self$units1 <- units1
    self$units2 <- units2
    self$token_dim <- as.integer(token_dim)
    self$embed_dim <- as.integer(emb1)
    self$interaction_network <- NULL
    self$num_features <- 0
    self$interaction_embeddings <- NULL
  },
  build = function(input_shape) {
    num_features <- input_shape[[2]]
    self$num_features <- num_features
    num_interactions <- as.integer((num_features * (num_features + 1)) / 2)
    hard_sigmoid <- CenteredHardSigmoidLayer()
    #
    ### Create shared interaction network
    inputs <- layer_input(shape = c(2*self$embed_dim + self$token_dim), name = "interaction_inputs")
    #
    dense1 <- layer_dense(inputs, units = self$units1, name = "interaction_dense1")
    activation1 <- layer_activation(dense1, activation = 'relu', name = "interaction_activation1")
    #
    dense2 <- layer_dense(activation1, units = self$units2,  name = "interaction_dense2")
    activation2 <- layer_activation(dense2, activation = 'relu', name = "interaction_activation2")
    #
    outputs <- layer_dense(activation2, units = 1L, activation = 'linear')  %>%
               hard_sigmoid()
    self$interaction_network <- keras_model(inputs = inputs, outputs = outputs, name = "interaction_network")
    #
    ### Create a unique interaction token
    self$interaction_token <- self$add_weight(
      name = 'interaction_token',
      shape = list(num_interactions, self$token_dim),
      initializer = 'uniform',
      trainable = TRUE
    )
    print("finished building")
  },
  call = function(inputs, ...) {
    num_features <- self$num_features
    interactions <- list()
    k = 0
    interaction_index <- 1
    for (i in 1:(num_features)) {
      for (j in i:num_features) {
        # select the pairs
        input_pair <- tf$concat(list(inputs[,i,], inputs[,j,]), axis = -1L)
        # Get the corresponding interaction token
        embed_lookup = tf$broadcast_to(self$interaction_token[interaction_index,,drop=TRUE], tf$stack(list(tf$shape(input_pair)[1], self$token_dim)))
        interaction_index <- interaction_index + 1
        # Concatenate the interaction token with the input pair
        input_with_embedding <- tf$concat(list(input_pair, embed_lookup), axis = -1L)
        # Pass these through shared interaction network
        interaction_output <- self$interaction_network(input_with_embedding)
        interactions[[k + 1]] <- interaction_output
        k = k + 1
      }
    }
    # Concatenate all interaction outputs
    interactions_concat <- tf$concat(interactions, axis = -1L)
    interactions_concat
  },
  compute_output_shape = function(input_shape) {
    num_features <- input_shape[[length(input_shape)]]
    num_interactions <- (num_features * (num_features + 1)) / 2
    c(input_shape[1], num_interactions)
  }
)


## pairwise interaction network (PIN)

PIN <- function(seed, q0, kk){
    tf$keras$backend$clear_session()
    set.seed(seed)
    set_random_seed(seed)
    embedding_list = list()
    #
    Design   <- layer_input(shape = c(q0[1]), dtype = 'float32')
    Volume   <- layer_input(shape = c(1), dtype = 'float32')
    #
    BrandEmb = Design[,q0[1]-1] %>%
      layer_embedding(input_dim = kk[1], output_dim = q0[3], input_length = 1) %>%
      layer_reshape(target_shape = c(1, q0[3]))
    #
    RegionEmb = Design[,q0[1]] %>%
      layer_embedding(input_dim = kk[2], output_dim = q0[3], input_length = 1) %>%
      layer_reshape(target_shape = c(1, q0[3]))
    #
    for (count in 1:(q0[1]-2)){
      embedding_list[[count]] = Design[,count:count] %>%
      layer_dense(units = q0[2]) %>%
      layer_dense(units = q0[3], activation = "tanh")  %>%
      layer_reshape(target_shape = c(1, q0[3]))
     }
    Embeds = embedding_list %>% layer_concatenate(axis = 1)
    Embeds = list(Embeds, BrandEmb, RegionEmb) %>% layer_concatenate(axis = 1)
    Pairs = PairwiseInteractionLayer(emb1=q0[3], units1=q0[4], units2=q0[5], token_dim=q0[6])
    Network = Embeds %>% Pairs %>% layer_dense(units = 1, activation = "exponential")
    Response = list(Network, Volume) %>% layer_multiply()
    keras_model(inputs = c(Design, Volume), outputs = c(Response))
    }



####################################################################################
#########  Prepare data for PIN
####################################################################################

# define the feature vector
features <- c("AreaX", "VehPowerX", "VehAgeX", "DrivAgeX", "BonusMalusX",
              "VehGasX", "DensityX", "VehBrandX", "RegionX")

(q0 <- length(features))
Xlearn  <- as.matrix(learn[, features])  # design matrix learning sample
Xtest   <- as.matrix(test[, features])   # design matrix test sample
Vlearn  <- as.matrix(learn$Exposure)     # time exposure
Vtest   <- as.matrix(test$Exposure)      # time exposure
Ylearn  <- as.matrix(learn$ClaimNb)
Ytest   <- as.matrix(test$ClaimNb)


####################################################################################
#########  Select the PIN hyper-parameters
####################################################################################

d1  <- c(10)       # embedding dimension
d2  <- c(20)       # FNN layer for continuous embedding
q1  <- c(30, 20)   # shared interaction network
d0  <- c(10)       # token dimension

qq <- c(q0, d2, d1, q1, d0)

# levels of categorical variables
kk <- c(length(unique(learn$VehBrandX)), length(unique(learn$RegionX)))

####################################################################################
#########  Fit the PIN: iterate for ensembling
####################################################################################

## We fit several PINs differently initialize to compute the ensemble predictor

T0 <- 10     # number of fitted PINs
results <- array(NA, dim=c(T0,2))

for (t in 1:T0){
   seed  <- 100+t-1
   model <- PIN(seed=seed, q0=qq, kk=kk)
   #model
   # initialize to the null model
   w0 <- get_weights(model)
   w0[[length(w0)-1]] <- array(0, dim=dim(w0[[length(w0)-1]]))
   w0[[length(w0)]] <- array(log(mu.hom), dim=dim(w0[[length(w0)]]))
   set_weights(model, w0)
   adam = optimizer_adam(learning_rate = 0.001)
   model %>% compile(optimizer = adam, loss = "poisson")
   ## define callback for early stopping
   if (!dir.exists("./Networks")){dir.create("./Networks")}
   path1 <- paste0("./Networks/PIN_Diag",seed,".weights.h5")
   model_write = callback_model_checkpoint(path1, save_best_only = T, verbose = 1, save_weights_only = T)
   learn_rate = callback_reduce_lr_on_plateau(factor = 0.9, patience = 5, cooldown = 0, verbose = 1)
   ### fitting takes long: simply load pre-fitted networks
   #   fit = fit(model, x = list(Xlearn, Vlearn), y = Ylearn, batch_size = 128,
   #            epochs=100, callbacks=list(model_write, learn_rate),
   #            validation_split = 0.1, verbose = 1, shuffle = TRUE)
   #   #
   #plot(fit)
   load_model_weights_hdf5(model,path1)
   learn$PIN =  as.vector(model %>% predict(list(Xlearn, Vlearn), batch_size = 2048))
   test$PIN  =  as.vector(model %>% predict(list(Xtest, Vtest), batch_size = 2048))
   results[t,] <- round(c(Poisson.Deviance(learn$PIN, learn$ClaimNb, rep(1, nrow(learn))),
                          Poisson.Deviance(test$PIN, test$ClaimNb, rep(1, nrow(test)))), 3)
   # building the ensemble predictor
   if (t==1){
       learn.PIN <- learn$PIN/T0
       test.PIN <- test$PIN/T0
       }else{
       learn.PIN <- learn.PIN+learn$PIN/T0
       test.PIN <- test.PIN+test$PIN/T0
       }
    }


# results of the individual fits
results
# average in-sample and out-of-sample loss
colMeans(results)
# standard deviations in these figures
sqrt(colMeans(results^2)-colMeans(results)^2)


# ensemble PIN, GLM and null model: in-sample and out-of-sample losses
rbind(round(c(Poisson.Deviance(learn.PIN, learn$ClaimNb, rep(1, nrow(learn))), Poisson.Deviance(test.PIN, test$ClaimNb, rep(1, nrow(test)))), 3),
      round(c(Poisson.Deviance(learn$GLM, learn$ClaimNb, rep(1, nrow(learn))), Poisson.Deviance(test$GLM, test$ClaimNb, rep(1, nrow(test)))), 3),
      round(c(Poisson.Deviance(mu.hom*learn$Exposure, learn$ClaimNb, rep(1, nrow(learn))), Poisson.Deviance(mu.hom*test$Exposure, test$ClaimNb, rep(1, nrow(test)))), 3))

